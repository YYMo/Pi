1. add usb touch driver
$ sudo cp usbtouchscreen.ko /lib/modules/3.4.29+
add "usbtouchscreen" to /etc/modules

2. install requried package and calibrate the touch
$ sudo apt-get install utouch xinput-calibrator && 
$ sudo insmod /lib/modules/3.4.29+/usbtouchscreen.ko &&
$ xinput_calibrator

3. add calibration data to /usr/share/X11/xorg.conf.d/99-calibration.conf

$ sudo cat > /usr/share/X11/xorg.conf.d/99-calibration.conf << EOF
Section "InputClass"
    Identifier    "calibration"
    MatchProduct    "eGalax Inc. USB TouchController"
    Option    "Calibration"    "xxx xxx xxx xxx"
EndSection

EOF

PS:"xxx xxx xxx xxx" is coordinates shown in the terminal

4. restart system

$ sudo reboot

 

sudo apt-get install matchbox
Soft keyboard