1��Creating IDC file
Getting root in terminal type su
cd /system/usr/idc/
busybox mount /system/ -o rw,remount
busybox cp gt80x.idc Vendor_0eef_Product_0001.idc

Note that the format of the file name is Vendor_XXXX_Product_XXXX.idc, available "cat/proc/ bus/input/devices" to see Vendor and Product ID, the file name can be modified accordingly.

2) Installation TSCalibration2.apk run the calibration procedure